QUnit.assert.ok( QUnit.isIE, "evaluated: nomodule script with src" );
